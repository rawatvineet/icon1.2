# iControl IDX
## Overview

This application set-ups indexes for the iControl application

## Configuring iControl
iControl requires data to be held within four indexes:
* _icontrol_observations_ holds the results of target performance evaluation against individual events.
* _icontrol_target_performance_ holds the net results of target performance evaluation for a given monitoring window, stored in a regular index.
* _icontrol_history_ holds audit data for changes to iControl Knowledge Objects e.g. Flows, Targets.

Only the iControl application account will requires access to these indexes, end-users do not directly access them.
A minimum retention policy of one year for the _icontrol_history_ and _icontrol_observations_ index is recommended, and 7 years for _icontrol_target_performance_.

9
# Copyright
Copyright 2020 HCL Technologies Limited All rights reserved.
